#ifndef SKEtCHIFY_H
#define SKEtCHIFY_H

#include <string>

void sketchify(std::string inputFile, std::string outputFile);

#endif

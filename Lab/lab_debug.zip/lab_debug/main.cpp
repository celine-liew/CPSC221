#include "sketchify.h"

int main() {
	sketchify("given_imgs/in.png", "out_ubc.png");
    sketchify("given_imgs/in_01.png", "out_rose.png");
    sketchify("given_imgs/in_02.png", "out_icics.png");
    sketchify("given_imgs/in_03.png", "out_nest.png");
    return 0;
}
